import * as Hooks from './Hooks';
import lang from './Language';

const TAG = "Image Loader Lib";

// NOTE Please put image path inside imageList
const imageList = {
  defaultIcon     : require('../Assets/img/sample.jpg'),
  splash_icon     : require('../Assets/icon/logo-splashscreen.png'),
  logo_hostory    : require('../Assets/icon/history.png'),
  logo_topup      : require('../Assets/icon/topup.png'),
  logo_qrcode     : require('../Assets/icon/qr.png'),
  logo_nfc        : require('../Assets/icon/nfc.png'),
  logo_rate       : require('../Assets/icon/rate.png'),
  logo_request    : require('../Assets/icon/request.png'),
  logo_help       : require('../Assets/icon/help.png'),
  icon_more       : require('../Assets/icon/more.png'),
  icon_cancel     : require('../Assets/icon/cancel-music.png'),
//Home
  logo2           : require('../Assets/icon/Home/logo.png'),
  logo_home       : require('../Assets/icon/Home/home.png'),
  logo_convert    : require('../Assets/icon/Home/convert.png'),
  logo_transfer   : require('../Assets/icon/Home/transfer.png'),
  logo_manage_bank: require('../Assets/icon/Home/manage-bank.png'),
  banner          : require('../Assets/icon/Home/banner.png'),
//Help
  icon_facebook   : require('../Assets/icon/Help/facebook.png'),
  icon_google     : require('../Assets/icon/Help/google-plus.png'),
  icon_whatsapp   : require('../Assets/icon/Help/whatsapp.png'),
//Top Up

//Menu
  icon_lang       : require('../Assets/icon/Menu/translate.png'),
  icon_edit_profile : require('../Assets/icon/Menu/edit.png'),
  icon_lock       : require('../Assets/icon/Menu/Lock.png'),
  icon_minus      : require('../Assets/icon/Menu/Minus.png'),
  icon_faq        : require('../Assets/icon/Menu/Speach.png'),
  icon_contact    : require('../Assets/icon/Menu/Earphones.png'),
  icon_signout    : require('../Assets/icon/Menu/on.png'),

  background      : require('../Assets/splashscreen.png'),
  icon_default    : require('../Assets/icon/logo-airmas.png'),
  icon_email      : require('../Assets/icon/icon-email.png'),
  password        : require('../Assets/icon/icon-password.png'),
  icon_agenda     : require('../Assets/icon/agenda.png'),
  arrow_back      : require('../Assets/icon/arrow_back.png'),
  cooperation     : require('../Assets/icon/cooperation.png'),
  email           : require('../Assets/icon/email.png'),
  icon_scan       : require('../Assets/icon/icon_scanner.png'),
  icon_scan2      : require('../Assets/icon/icon_scanner2.png'),
  menu            : require('../Assets/icon/menu.png'),
  notFind         : require('../Assets/icon/not_find.png'),
  successScan     : require('../Assets/icon/success_scan.png'),
  back_splash     : require('../Assets/background.png'),
  back_error      : require('../Assets/errorscreen.png'),
  back_succest    : require('../Assets/succestscreen.png'),
  logo            : require('../Assets/icon/logo.png'),
};

function fetchObject(prop) {
  // split prop
  var _index = prop.indexOf('.');

  // prop split found
  if(_index > -1) {
    // re-execute this function to get property inside other property
    return fetchObject(prop.substr(_index+1));
  }

  return imageList[prop];
}

export default function loader(index, default_type = 'profile') {
  let isHaveSlash = /\//.test(index);
  let isFullURL = /http/.test(index);

  if(!index || (isHaveSlash && !isFullURL)) {
    return fetchObject(`${default_type}_default`); // as Default Image
  } else if(isFullURL) {
    return { uri: index };
  } else {
    let imgValue = fetchObject(index);
    return imgValue;
  }
}
