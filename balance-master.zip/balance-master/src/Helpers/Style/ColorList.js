export const color = {
  blue1 : '#008FFB',
  blue2 : '#00ABFF',
  grey1 : '#B8B8BD',
  grey2 : '#F2F1F6',
  defaultBackground  : 'rgb(9, 132, 227)',
  borderInput        : 'rgb(75, 170, 243)',
  textPlaceholder    : '#364246',
  textItems          : '#151717',
  buttonColor        : '#0d7ba7',
  textButtonDefault  : '#FFFFFF',

  backgroundIcon1     : 'rgb(9, 132, 227)',
  backgroundIcon2     : 'rgb(108, 92, 231)',
  backgroundIcon3     : 'rgb(0, 184, 148)',
};