export const encoding = 'id'; // Language Encoding
export const lang = {
  title: {
    home: 'Rumah',
    counter: 'Penghitung',
    splash: 'Percikan'
  }
};
