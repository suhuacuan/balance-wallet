export const encoding = 'en'; // Language Encoding
export const lang = {
  title: {
    home: 'Home',
    counter: 'Counter',
    splash: 'Splash'
  }
};
