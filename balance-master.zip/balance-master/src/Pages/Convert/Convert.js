import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  ImageBackground,
  Keyboard,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  InputGroup,
  Form,
  Label,
  Icon,
  Body,
  Input,
  Item,
  Left,
  Right,
  ListItem,
  CheckBox,
  Title,
  List,
  Picker,
  Row,
  Col
} from "native-base";

import { connect } from 'react-redux';

import * as Http from 'Balance/src/Helpers/Http';
import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import { color } from 'Balance/src/Helpers/Style/ColorList';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import lang from 'Balance/src/Helpers/Language';

const {width,height} = Dimensions.get('window');

class Convert extends Component {

  static navigationOptions = {
    header: {
      visible: false,
    }
  };

  constructor(props) {
    super(props);
    this.state = {
      price:'101000',
      fee: '10000',
      total:'111000',
      selected: "01",
      nominal: '10'
    }
  }

  _onLogin() {
    this.props.navigation.goBack();
  }

  _onRate() {
    this.props.navigation.navigate('Home');
  }

  seePassword() {
    if (this.state.showPassword) {
      this.setState({
        showPassword : false,
        nameIcon : "ios-eye",
      });
    }else{
      this.setState({
        showPassword : true,
        nameIcon : "ios-eye-off",
      });
    }
  }    

  render=()=> {
    return (
      <Container>
        <Header style={{backgroundColor:color.blue1}}>
          <Left>
            <Button transparent 
              onPress={()=>this.props.navigation.goBack()}>
              <Icon name='arrow-back' style={{color:'white'}} />
            </Button>
          </Left>
          <Body>
            <Title style={{color:'white', width:(width*0.7)}}> Convert Currency </Title>
          </Body>
          <Right/>
        </Header>

        <Content>
          <Text style={{fontSize:16, color:color.blue2, textAlign:'center',marginTop:20}}>The Currency</Text>
          <Text style={{fontSize:16, color:color.blue2, textAlign:'center'}}>you want to Change</Text>
          <ListItem style={{borderBottomWidth:0}}>
            <Left>
              <Item regular style={{width:(width*0.2)}}>
                <Picker mode="dropdown"
                  iosHeader="Select your"
                  style={{ width: undefined }}
                  selectedValue={this.state.selected}
                  onValueChange={(value)=>this.setState({selected:value})}
                >
                  <Picker.Item label="AUD" value="01" />
                  <Picker.Item label="ATM Card" value="02" />
                  <Picker.Item label="Debit Card" value="03" />
                  <Picker.Item label="Credit Card" value="04" />
                  <Picker.Item label="Net Banking" value="05" />
                </Picker>
              </Item>
            </Left>
            <Right>
              <Item regular style={{width:(width*0.7)}}>
                <Input 
                  placeholder='Jumlah Nominal' 
                  onChangeText={(nominal) => this.setState({ nominal })}
                  value={this.state.nominal}
                  style={{
                    color:color.grey1, 
                    fontSize:14
                  }}
                />
              </Item>
            </Right>
          </ListItem>
          <View style={{
            marginTop:5,
            marginLeft:20,
            marginBottom:20
          }}>
          <Text style={{fontSize:16, color:color.blue2}}> Rate ~ 1 AUD = 10.100 IDR </Text>
          </View>
          <List>
            <ListItem>
              <Text>Rp. {Hooks.formatCurrency(this.state.price,'')}</Text>
            </ListItem>
            <ListItem>
              <Text>Fee {Hooks.formatCurrency(this.state.fee,'')}</Text>
            </ListItem>
            <ListItem>
              <Text>Total {Hooks.formatCurrency(this.state.total,'')}</Text>
            </ListItem>
          </List>
        </Content>
        <View style={{
          borderTopColor:color.grey1,
          borderTopWidth: 0.7,
          justifyContent:'center',
          height:'10%'
        }}>
          <View style={{
            flexDirection:'row',
            alignSelf:'center',
          }}>
            <Button 
              block
              style={{
                marginLeft:5,
                borderRadius:5,
                width:(width * 0.45),
                marginRight:5,
                backgroundColor:'red'
              }}
              onPress={() => console.log('charts')}
            >
              <Text style={{color:'white'}}>Clear</Text>
            </Button>

            <Button 
              block
              style={{
                marginLeft:5,
                borderRadius:5,
                width:(width * 0.45),
                marginRight:5,
                backgroundColor:color.blue2
              }}
              onPress={() => console.log('Rate Alert')}
            >
              <Text style={{color:'white'}}>Convert</Text>
            </Button>
          </View>
        </View>
      </Container>
    );
  }
}


const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(Convert);
