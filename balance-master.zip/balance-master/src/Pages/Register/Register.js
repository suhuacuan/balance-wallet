import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  ImageBackground,
  Keyboard,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  InputGroup,
  Form,
  Label,
  Icon,
  Body,
  Input,
  Item,
  Left,
  Right,
  ListItem,
  CheckBox
} from "native-base";

import { connect } from 'react-redux';

import * as Http from 'Balance/src/Helpers/Http';
import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import { color } from 'Balance/src/Helpers/Style/ColorList';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import lang from 'Balance/src/Helpers/Language';

class Register extends Component {

  static navigationOptions = {
    header: {
      visible: false,
    }
  };

  constructor(props) {
    super(props);
    this.state = {
      email: '',
      checked: false, 
      password: '',
      isLoading: false,
      nameIcon    : "ios-eye-off",
      showPassword: true
    }
  }

  _onLogin() {
    this.props.navigation.goBack();
  }

  _onRegister() {
    this.props.navigation.navigate('Home');
  }

  seePassword() {
    if (this.state.showPassword) {
      this.setState({
        showPassword : false,
        nameIcon : "ios-eye",
      });
    }else{
      this.setState({
        showPassword : true,
        nameIcon : "ios-eye-off",
      });
    }
  }    

  render=()=> {
    return (
      <Container>
        <View style={{flex:1}}></View>
        <View>
          <Image
            style={{
              alignSelf: 'center',
              marginBottom: 20,
              resizeMode: 'contain',
              width: 130,
              height: 110
            }}
            resizeMode="contain"
            source={ImageLoader('logo')}
          />
          <View style={{
            alignItems:'flex-start',
            marginBottom: 20,
            paddingLeft:20,
            paddingRight:20
          }}>
            <Text style={{color:color.blue1, fontSize:20, fontWeight:'700'}}>
              Sign Up
            </Text>
            <Text style={{color:color.grey1, fontSize:14, fontWeight:'500'}}>
              Sign in to continue
            </Text>
          </View>

          <Form style={{
            maxWidth:500,
            alignItems: 'center',
            alignSelf:'center',
            paddingLeft:20,
            paddingRight:20
          }}>
            <Item style={{
              width:'100%',
              borderRadius:10,
              marginLeft:0,
              paddingLeft:0,
              marginBottom:10,
              marginRight:0,
              paddingRight:0,
              borderBottomWidth:0,
              backgroundColor: color.grey2
            }}>
              <Input
                onChangeText={(email) => this.setState({ email })}
                value={this.state.email}
                style={{
                  color:color.textItems, 
                  fontSize:14
                }}
                placeholderTextColor={color.grey1}
                placeholder='Mobile Number'
                keyboardType='email-address'
              />
            </Item>

            <Item style={{
              width:'100%',
              borderRadius:10,
              marginLeft:0,
              paddingLeft:0,
              marginBottom:10,
              marginRight:0,
              paddingRight:0,
              borderBottomWidth:0,
              backgroundColor: color.grey2
            }}>
              <Input
                onChangeText={(password) => this.setState({ password })}
                style={{color:color.textItems, fontSize:14}}
                value={this.state.password}
                placeholderTextColor={color.grey1}
                placeholder='PIN Number'
                secureTextEntry={this.state.showPassword}
              />

              <View style={{position:"absolute", right:0}}>
                <Icon 
                  style={{color:'#1A4566'}} 
                  name={this.state.nameIcon} 
                  onPress={() => this.seePassword()}
                />
              </View>
            </Item>

            <Item style={{
              width:'100%',
              borderRadius:10,
              marginLeft:0,
              paddingLeft:0,
              marginBottom:10,
              marginRight:0,
              paddingRight:0,
              borderBottomWidth:0,
              backgroundColor: color.grey2
            }}>
              <Input
                onChangeText={(password) => this.setState({ password })}
                style={{color:color.textItems, fontSize:14}}
                value={this.state.password}
                placeholderTextColor={color.grey1}
                placeholder='Confirm PIN Number'
                secureTextEntry={this.state.showPassword}
              />

              <View style={{position:"absolute", right:0}}>
                <Icon 
                  style={{color:'#1A4566'}} 
                  name={this.state.nameIcon} 
                  onPress={() => this.seePassword()}
                />
              </View>
            </Item>

            <View style={{
              width:'100%',
              flexDirection:'row',
              marginTop:10
            }}>
              <Left>
                <CheckBox checked={this.state.checked} onPress={()=> this.setState({checked : !this.state.checked })}/>
              </Left>
              <View style={{marginLeft:20}}>
                <Text style={{color:color.textPlaceholder, fontSize:14, fontWeight:'500'}}>
                  I agree to the  <Text style={{color:color.blue1, fontSize:14, fontWeight:'500'}}>
                    Terms of Service
                  </Text> and <Text style={{color:color.blue1, fontSize:14, fontWeight:'500'}}>
                    Privacy Policy
                  </Text>
                </Text>
              </View>
            </View>

            <Button
              full
              style={{
                marginTop:20,
                backgroundColor: color.blue2,
                borderRadius:10,
              }}
              onPress={() => this._onLogin()}>
              <Text style={{fontSize:16, color: color.textButtonDefault, fontWeight:'600'}}>
                SIGN UP
              </Text>
            </Button>

            <Button
              full
              style={{
                marginTop:10,
                backgroundColor: color.blue1,
                borderRadius:10,
              }}
              onPress={() => this._onRegister()}>
              <Text style={{fontSize:16, color: color.textButtonDefault, fontWeight:'600'}}>
                SIGN IN
              </Text>
            </Button>
            
           
          </Form>
        </View>
        <View style={{flex:1}}></View>
      </Container>
    );
  }
}


const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(Register);
