import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Icon,
  Left,
  Body,
  Input,
  Right,
  Title,
  Item
} from "native-base";

import { connect } from 'react-redux';

import lang from 'Balance/src/Helpers/Language';
// import base64 from 'react-native-base64';
import QRCodeScanner from 'react-native-qrcode-scanner';
import * as Http from 'Balance/src/Helpers/Http';
// import Orientation from 'react-native-orientation';

const {width, height} = Dimensions.get('window');
const HEIGHT_SCREEN =  height/1.5 ;
const TOP = HEIGHT_SCREEN / 28;
const BOTTOM = HEIGHT_SCREEN /10;
const SCREEN_WIDTH = (width/1.5);

class Scanner extends Component {

  constructor(props) {
    super(props);
    this.state = {
      successType:false
    }
  }

  componentDidMount() {
    // this locks the view to Portrait Mode
    // Orientation.lockToPortrait();
  }

  componentWillUnmount() {
    // Remember to remove listener
    // Orientation.unlockAllOrientations();
  }


  onSuccess(info) {
    try {
      // let dataScan = base64.decode(info.data);
      // let jsonData = JSON.parse(dataScan);
      // this.sendParams(jsonData);
    }
    catch(err) {
      this.props.navigation.navigate('ErrorPages'); 
      // Alert.alert(
      //   'Oops',
      //   'Data Tidak Di Temukan',
      //   [
      //     {text: 'OK', onPress: () =>  this.scanner.reactivate()},
      //   ],
      //   {cancelable: false}
      // )
    }
  }

  sendParams(data = null) {
    let dataPush = {
      custom_link: data.link,
      methode: 'POST',
      headers:{
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      data: {
        module: data.module,
        code: data.code
      }
    }
    Http.createRequest(dataPush).then((response) => {
      console.log('response',response);
      Alert.alert("Sukses", "Kode Sukses");
    }).catch((err) => {
      console.log('error',err);
    });
  }

  checkRenderBody() {
    if (this.state.successType) {
     return null; 
    }
    return (
      <Content>
        <QRCodeScanner
          onRead={(params) => this.onSuccess(params)}
          cameraStyle={{ height:height}}
          ref={(node) => {this.scanner = node}}
          showMarker={true}
          customMarker={
            <View style={styles.rectangleContainer}>
                <Icon
                  name='qr-scanner'
                  style={{
                    fontSize:SCREEN_WIDTH,
                    bottom: BOTTOM,
                    color:"white"
                  }}
                />
            </View>
          }
        />

      </Content>
    );
  }

  checkRenderHeader() {
    if (this.state.successType) {
      return null;
    }
    return (
      <Header style={{backgroundColor: '#0984E3'}}>
        <Left>
          <Button transparent onPress={() => this.props.navigation.goBack()}>
            <Icon style={{color:'white'}} name="arrow-back" />
          </Button>
        </Left>
        <Body>
          <Title style={{color:'white'}}>Scanner</Title>
        </Body>
        <Right />
      </Header>
    );
  }

  render=()=> {
    return (
      <Container>
        {this.checkRenderHeader()}
        {this.checkRenderBody()}
      </Container>
    );
  }
}

  const styles = StyleSheet.create({
    rectangleContainer: {
      flex: 1,
      alignItems: "center",
      alignSelf: "center",
      justifyContent: "center",
      backgroundColor: "transparent"
    }  
  });

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(Scanner);
