import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Modal,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Picker,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item,
  Tabs,
  Tab,
  TabHeading
} from "native-base";

import { connect } from 'react-redux';

import HeaderDetail from 'Balance/src/Components/GlobalHeader/HeaderDetail';

import lang from 'Balance/src/Helpers/Language';
import * as Http from 'Balance/src/Helpers/Http';
import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const WIDTH = Dimensions.get('window').width;
const CARD = WIDTH * (45/100);
const maxWidth = WIDTH * (97/100);
const HEIGHT = Dimensions.get('window').height;

class TopUp extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
      image:'',
      typeImg:'',
      selected: "01",
      selected2: undefined,
      price:'999999',
      max:'10000000',
      oPenModal:false
    };
  }

  componentDidMount(){
    // var img = Session.getValue(Session.USER_PIC);
    // var typeImg = img.substring(img.length - 3);
    // this.setState({
    //   image:img,
    //   typeImg:typeImg
    // });
  }


  _onLogout(){
    // kill all session
    Session.destroy(); 
    this.props.navigation.navigate('Splash'); 
  }

  _showModal() {

    return (
      <Modal
        transparent={true}
        animationType="fade"
        visible={this.state.oPenModal}
        onRequestClose={() => this.setState({oPenModal: false})}>
        
        <View style={{
          flex: 1,
          alignItems: 'center',
          flexDirection: 'column',
          justifyContent: 'space-around',
          backgroundColor: '#00000040'
        }}>
          <View style={{
            backgroundColor: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-around',
            //height: Hooks.normalize(150),
            width:(WIDTH * 0.8)
          }}>
            <View style={{alignItems:'center'}}>
              <View style={{flexDirection:'row'}}>
                <Body/>
                <View style={{bottom:12,right:1}}>
                  <Button transparent
                    onPress={() => this.setState({oPenModal: false})}>
                      <Image style={{height:15,resizeMode:'contain'}} source={ImageLoader('icon_cancel')}/>
                  </Button>
                </View>
              </View>
              
              <View style={{marginLeft:10, marginBottom:20, alignItems:'flex-start',alignSelf:'flex-start'}}>
                <Label>Send Message :</Label>
                <View style={{marginLeft:10, marginTop:20, flexDirection:'row'}}>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_whatsapp')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_facebook')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_google')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_more')}/>
                  </Button>
                </View>
              </View>

            </View>
          </View>
        </View>
      </Modal>
    )

  }

  render=()=> {
    return (
      <Container>
        {this._showModal()}
        <HeaderDetail navigation = {this.props.navigation}/>

          <Content>
            <Label style={{fontWeight:'600',marginLeft:10, marginBottom:10}}> TOP UP </Label>
            <View style={{
              flexDirection:'row',
              justifyContent:'space-between',
              alignItems:'center',
              backgroundColor: color.grey2,
              height:'20%',
              borderRadius:5,
              marginLeft:20,
              marginRight:20,
              shadowColor: "#000",
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.25,
              shadowRadius: 3.84,
              elevation: 5,
            }}>
              <Text style={{fontSize:14,color:color.grey1}}> BALANCE </Text>
              <Text style={{fontSize:16, fontWeight:'600',marginRight:5}}>{Hooks.formatCurrency(this.state.price)}</Text>
            </View>
            <Text style={{fontSize:12, textAlign:'center', marginTop:5}}>Maksimal transfer saldo BALANCE {Hooks.formatCurrency(this.state.max)}</Text>

            <ListItem style={{borderBottomWidth:0}}>
              <Left>
                <Item regular style={{width:(WIDTH*0.2)}}>
                  <Picker mode="dropdown"
                    iosHeader="Select your"
                    style={{ width: undefined }}
                    selectedValue={this.state.selected}
                    onValueChange={(value)=>this.setState({selected:value})}
                  >
                    <Picker.Item label="Rp" value="01" />
                    <Picker.Item label="$ USD" value="02" />
                    <Picker.Item label="Debit Card" value="03" />
                    <Picker.Item label="Credit Card" value="04" />
                    <Picker.Item label="Net Banking" value="05" />
                  </Picker>
                </Item>
              </Left>
              <Right>
                <Item regular style={{width:(WIDTH*0.7)}}>
                  <Input 
                    placeholder='Jumlah Nominal' 
                    onChangeText={(nominal) => this.setState({ nominal })}
                    value={this.state.nominal}
                    style={{
                      color:color.grey1, 
                      fontSize:14
                    }}
                  />
                </Item>
              </Right>
            </ListItem>

            <View style={{marginLeft:10}}>
              <Label style={{fontSize:14}}>Top Up Method</Label>
              <Item picker>
                <Picker
                  mode="dropdown"
                  iosIcon={<Icon name="arrow-down" />}
                  style={{ width: undefined }}
                  placeholder="Select a Payment Method"
                  placeholderStyle={{ color: "#000000" }}
                  placeholderIconColor="#000000"
                  selectedValue={this.state.selected2}
                  onValueChange={(value)=>this.setState({selected2:value})}
                >
                  <Picker.Item label="ATM" value="key0" />
                  <Picker.Item label="Internet Banking" value="key1" />
                  <Picker.Item label="Mobile Banking" value="key2" />
                </Picker>
              </Item>
            </View>

          </Content>

          <View style={{
            justifyContent:'center',
            height:'10%'
          }}>
            <View style={{
              flexDirection:'row',
              alignSelf:'center',
            }}>
              <Button 
                block
                style={{
                  marginLeft:5,
                  borderRadius:5,
                  width:(WIDTH * 0.45),
                  marginRight:5,
                  backgroundColor:'red'
                }}
                onPress={() => console.log('charts')}
              >
                <Text style={{color:'white'}}>Clear</Text>
              </Button>

              <Button 
                block
                style={{
                  marginLeft:5,
                  borderRadius:5,
                  width:(WIDTH * 0.45),
                  marginRight:5,
                  backgroundColor:color.blue2
                }}
                onPress={() => console.log('Rate Alert')}
              >
                <Text style={{color:'white'}}>Cofirm</Text>
              </Button>
            </View>
          </View>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  img_logo:{
    width: 60, 
    height: 70,
    resizeMode:'contain',
    marginBottom:10
  },
  img_icon:{
    resizeMode: 'contain',
    width: 50,
    marginTop:50/2,
    height: 50
  },
  img_icon2:{
    resizeMode: 'contain',
    marginRight:10/2,
    width: 45,
    marginTop:25/2,
    height: 45
  },
  opacity:{
    alignItems:'center',
    width:80,
    position:'absolute',
    bottom:10,
    height:80,
    borderWidth: 5,
    borderColor: '#f7f8fa',
    borderRadius: 80/2
  },
  view_icon:{
    alignItems: 'center',
    marginTop: 20,
    width: 100, 
    height: 100,  
    borderRadius: 100/2,
  },
  avatar:{
    top: -80,
    flexDirection: 'column',
    alignItems: 'center'
  }
});

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(TopUp);
