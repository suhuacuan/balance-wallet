import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Modal,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Picker,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item,
  Tabs,
  Tab,
  TabHeading
} from "native-base";

import { connect } from 'react-redux';

import HeaderDefault from 'Balance/src/Components/GlobalHeader/HeaderDefault';

import lang from 'Balance/src/Helpers/Language';
import * as Http from 'Balance/src/Helpers/Http';
import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const WIDTH = Dimensions.get('window').width;
const CARD = WIDTH * (45/100);
const maxWidth = WIDTH * (97/100);
const HEIGHT = Dimensions.get('window').height;

class TopUp extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
      image:'',
      typeImg:'',
      selected: "01",
      selected2: undefined,
      price:'999999',
      max:'10000000',
      oPenModal:false
    };
  }

  componentDidMount(){
    // var img = Session.getValue(Session.USER_PIC);
    // var typeImg = img.substring(img.length - 3);
    // this.setState({
    //   image:img,
    //   typeImg:typeImg
    // });
  }


  _onLogout(){
    // kill all session
    Session.destroy(); 
    this.props.navigation.navigate('Splash'); 
  }

  _showModal() {

    return (
      <Modal
        transparent={true}
        animationType="fade"
        visible={this.state.oPenModal}
        onRequestClose={() => this.setState({oPenModal: false})}>
        
        <View style={{
          flex: 1,
          alignItems: 'center',
          flexDirection: 'column',
          justifyContent: 'space-around',
          backgroundColor: '#00000040'
        }}>
          <View style={{
            backgroundColor: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-around',
            //height: Hooks.normalize(150),
            width:(WIDTH * 0.8)
          }}>
            <View style={{alignItems:'center'}}>
              <View style={{flexDirection:'row'}}>
                <Body/>
                <View style={{bottom:12,right:1}}>
                  <Button transparent
                    onPress={() => this.setState({oPenModal: false})}>
                      <Image style={{height:15,resizeMode:'contain'}} source={ImageLoader('icon_cancel')}/>
                  </Button>
                </View>
              </View>
              
              <View style={{marginLeft:10, marginBottom:20, alignItems:'flex-start',alignSelf:'flex-start'}}>
                <Label>Send Message :</Label>
                <View style={{marginLeft:10, marginTop:20, flexDirection:'row'}}>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_whatsapp')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_facebook')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_google')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_more')}/>
                  </Button>
                </View>
              </View>

            </View>
          </View>
        </View>
      </Modal>
    )

  }

  render=()=> {
    return (
      <Container>
        {this._showModal()}
        <HeaderDefault navigation = {this.props.navigation}/>

        <Content>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_lang')}/>
            </Left>
            <Body>
              <Text> Language </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_edit_profile')}/>
            </Left>
            <Body>
              <Text> Edit Profile </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_lock')}/>
            </Left>
            <Body>
              <Text> Change PIN </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_minus')}/>
            </Left>
            <Body>
              <Text> About Beep </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_faq')}/>
            </Left>
            <Body>
              <Text> FAQ </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_contact')}/>
            </Left>
            <Body>
              <Text> Contact Beep </Text>
            </Body>
          </ListItem>
          <ListItem icon>
            <Left>
              <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('icon_signout')}/>
            </Left>
            <Body>
              <Text> Sign Out </Text>
            </Body>
          </ListItem>
        </Content>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  img_logo:{
    width: 60, 
    height: 70,
    resizeMode:'contain',
    marginBottom:10
  },
  img_icon:{
    resizeMode: 'contain',
    width: 50,
    marginTop:50/2,
    height: 50
  },
  img_icon2:{
    resizeMode: 'contain',
    marginRight:10/2,
    width: 45,
    marginTop:25/2,
    height: 45
  },
  opacity:{
    alignItems:'center',
    width:80,
    position:'absolute',
    bottom:10,
    height:80,
    borderWidth: 5,
    borderColor: '#f7f8fa',
    borderRadius: 80/2
  },
  view_icon:{
    alignItems: 'center',
    marginTop: 20,
    width: 100, 
    height: 100,  
    borderRadius: 100/2,
  },
  avatar:{
    top: -80,
    flexDirection: 'column',
    alignItems: 'center'
  }
});

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(TopUp);
