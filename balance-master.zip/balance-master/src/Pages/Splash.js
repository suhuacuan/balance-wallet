import React, { Component } from 'react';

import {
  ActivityIndicator,
  StyleSheet,
  Image,
  ImageBackground,
  Dimensions,
  View
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Icon,
  Body,
  Input,
  Item
} from "native-base";

import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const TAG = "SPLASH SCREEN";
const TIME_2_TICK =  2000;

class Splash extends Component {

  constructor(props) {
    super(props);
    this.state = {
      showLogo: false,
      countdown: 3,
    }
  }

  componentDidMount() {

    this.timesStart();

    this.timeOn = setTimeout(() => {
      this._navigation();
    },TIME_2_TICK);
  }
  
  timesStart() {
    this.time = setTimeout(() => {
      if(this.state.countdown === 0) {
        clearTimeout(this.time);
        this.setState({ showLogo: true });
      } 
      else {
        this.timesStart();
        let count = this.state.countdown - 1;
        this.setState({ countdown: count });
      }
    },125);
  }

  _navigation() {
    Session.prepare().then((dataSession) => {
      // Check Session
      if(dataSession && dataSession[Session.IS_LOGIN]) {
        clearTimeout(this.timeOn);
        clearTimeout(this.time);
        this.props.navigation.navigate('Home');
      } else {
        clearTimeout(this.timeOn);
        clearTimeout(this.time);
        this.props.navigation.navigate('Home');
        // this.props.navigation.navigate('Login');
      }
    }).catch((err) => {
      clearTimeout(this.timeOn);
      clearTimeout(this.time);
      // this.props.navigation.navigate('Login');
      Hooks.consoleLog(TAG + "Session Prepare Catch", err.message);
    });
  }

  logoShow() {

    // if (this.state.showLogo) {
    //   return(
        
    //   );
    // }

    // return null;
  }

  render=()=> {
    return(
      <Container style={{backgroundColor:color.blue2}}>
        <View style={{
          flex: 1,
          flexDirection: 'column',
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          <Image
            style={{
              alignSelf: 'center',
              resizeMode: 'contain',
              width: 100,
              height: 100,
              marginBottom:10,
            }}
            resizeMode="contain"
            source={ImageLoader('splash_icon')}
          />
          <ActivityIndicator size="large"/>
        </View>
        
        <View style={{
          backgroundColor:'white',
          justifyContent:'center',
          alignItems:'center',
          height:'8%'
        }}>
          <Text style={{color:color.blue1, fontSize:18, fontWeight:'700'}}>
            Loading Screen
          </Text>
        </View>
      </Container>
    );
  }
}

export default Splash;
