import React, { Component } from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Dimensions
} from 'react-native';
import { 
  Container, 
  Header, 
  Content, 
  List, 
  ListItem, 
  Text,
  Icon,
  Button,
  Left,
  Right,
  Body,
  Title, 
} from 'native-base';

import lang from 'Balance/src/Helpers/Language';
import * as Session from 'Balance/src/Helpers/Session';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

export default class ListHeaderExample extends Component {

  _onLogout(){
    // kill all session
    Session.destroy(); 
    this.props.navigation.navigate('Splash'); 
  }

  render() {
    return (
      <Container>
        <Header 
          style={{backgroundColor:'#FFFFFF',color: 'black'}}
        >
          <Left>
            <Button
              transparent
              onPress={() => this.props.navigation.goBack()}
            >
              <Icon 
                style={{color: 'black',marginLeft: 10}} 
                name='arrow-back'
              />
            </Button>
          </Left>
          <Body>
            <Title style={{color: 'black'}}> Back to Dashboard</Title>
          </Body>
        </Header>

        <Content>
          <List>
            <ListItem button onPress={() => console.log('tester')}>
              <Text> About Us </Text>
            </ListItem>
            <ListItem button onPress={() => this._onLogout()}>
              <Text> Logout </Text>
            </ListItem>
          </List>
        </Content>
      </Container>
    );
  }

}