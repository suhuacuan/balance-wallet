import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item
} from "native-base";

import { connect } from 'react-redux';

import * as Http from 'Balance/src/Helpers/Http';
import * as Session from 'Balance/src/Helpers/Session';
import * as Hooks from 'Balance/src/Helpers/Hooks';
import { color } from 'Balance/src/Helpers/Style/ColorList';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import lang from 'Balance/src/Helpers/Language';

const {width, height} = Dimensions.get('window');

export default class ErrorPages extends Component {

  constructor(props) {
    super(props);
    this.state = {
      successType:false
    }
  }

  render() {
    return (
      <ImageBackground
        source={ImageLoader('back_error')}
        style={{with:'100%',height:'100%'}}
      >
        <View style={{marginLeft:20}}>
          <Image
            style={{
              resizeMode: 'contain',
              width: '40%',
              height: '40%',
              marginTop:20,
              marginBottom:10,
            }}
            resizeMode="contain"
            source={ImageLoader('notFind')}
          />
            <Text style={{marginBottom:10, fontSize:20, fontWeight:'bold' , color:'white'}}> Unrecognized QR Code </Text>
            <Text style={{marginBottom:10, color:'white'}}> Please scan the code again </Text>
        </View>

        <Button
          style={{
            marginTop:30,
            backgroundColor:'transparante',
            borderColor:'white',
            borderRadius:25,
            position:'absolute',
            bottom:30,
            left:(width/2.4)
          }}
        >
          <Text> Scan Again </Text>
        </Button>
      </ImageBackground>
    );
  }
}