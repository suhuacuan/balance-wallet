import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Modal,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item,
  Tabs,
  Tab,
  TabHeading
} from "native-base";

import { connect } from 'react-redux';

import HeaderDefault from 'Balance/src/Components/GlobalHeader/HeaderDefault';

import lang from 'Balance/src/Helpers/Language';
import * as Session from 'Balance/src/Helpers/Session';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const WIDTH = Dimensions.get('window').width;
const CARD = WIDTH * (45/100);
const maxWidth = WIDTH * (97/100);
const HEIGHT = Dimensions.get('window').height;

class Home extends Component {

  dataItems = [{
    images: ImageLoader('logo_qrcode'),
    name  : 'QR',
    nav   : ''
  }, {
    images: ImageLoader('logo_nfc'),
    name  : 'NFC',
    nav   : ''
  }, {
    images: ImageLoader('logo_rate'),
    name  : 'Rate',
    nav   : 'Rate'
  }, {
    images: ImageLoader('logo_request'),
    name  : 'Request',
    nav   : ''
  }
];

  
  constructor(props) {
    super(props);
    this.state = {
      image:'',
      typeImg:'',
      oPenModal:false
    };
  }

  componentDidMount(){
    // var img = Session.getValue(Session.USER_PIC);
    // var typeImg = img.substring(img.length - 3);
    // this.setState({
    //   image:img,
    //   typeImg:typeImg
    // });
  }

  listItems() {
    var columns = 2;
    
    return(
      <View style={{alignSelf:'center',maxWidth:maxWidth}}>
        <FlatList
          data={this.dataItems}
          horizontal={false}
          keyExtractor={ (item, index) => index.toString() }
          renderItem={({item, index}) => {
            return (
              <View style={{width: (CARD/1.5), marginHorizontal: 5, marginTop:20}}>
                <TouchableOpacity 
                  onPress={()=> this.props.navigation.navigate(item.nav)}
                  style={{ 
                    flexDirection:'column',
                    justifyContent:'center',
                    alignItems:'center'
                  }}
                >
                  <Image style={{width:50,height:50,resizeMode:'contain'}} source={item.images}/>
                  <Text style={{color:color.blue1,fontSize:16, fontWeight:'800', marginTop:10}}>{item.name}</Text>
                </TouchableOpacity>
              </View>
            );
            }
          }
          numColumns={columns}
        />
      </View>
    );
  }

  _onLogout(){
    // kill all session
    Session.destroy(); 
    this.props.navigation.navigate('Splash'); 
  }

  _showModal() {

    return (
      <Modal
        transparent={true}
        animationType="fade"
        visible={this.state.oPenModal}
        onRequestClose={() => this.setState({oPenModal: false})}>
        
        <View style={{
          flex: 1,
          alignItems: 'center',
          flexDirection: 'column',
          justifyContent: 'space-around',
          backgroundColor: '#00000040'
        }}>
          <View style={{
            backgroundColor: '#ffffff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-around',
            //height: Hooks.normalize(150),
            width:(WIDTH * 0.8)
          }}>
            <View style={{alignItems:'center'}}>
              <View style={{flexDirection:'row'}}>
                <Body/>
                <View style={{bottom:12,right:1}}>
                  <Button transparent
                    onPress={() => this.setState({oPenModal: false})}>
                      <Image style={{height:15,resizeMode:'contain'}} source={ImageLoader('icon_cancel')}/>
                  </Button>
                </View>
              </View>
              
              <View style={{marginLeft:10, marginBottom:20, alignItems:'flex-start',alignSelf:'flex-start'}}>
                <Label>Send Message :</Label>
                <View style={{marginLeft:10, marginTop:20, flexDirection:'row'}}>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_whatsapp')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_facebook')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_google')}/>
                  </Button>
                  <Button transparent style={{marginRight:10,marginLeft:10}}>
                    <Image style={{width:40,height:40,resizeMode:'contain'}} source={ImageLoader('icon_more')}/>
                  </Button>
                </View>
              </View>

            </View>
          </View>
        </View>
      </Modal>
    )

  }

  render=()=> {
    return (
      <Container>
        {this._showModal()}
        <HeaderDefault navigation = {this.props.navigation}/>

          <Content>
            <View style={{flexDirection:'row',justifyContent:'center'}}>
              <TouchableOpacity
                onPress={()=> this.props.navigation.navigate('History')}
                style={{ 
                  flexDirection:'column',
                  justifyContent:'center',
                  alignItems:'center'
                }}
              >
                <Image style={{width:50,height:50,resizeMode:'contain'}} source={ImageLoader('logo_hostory')}/>
                <Text style={{color:color.blue1,fontSize:16, fontWeight:'800', marginTop:10}}>History</Text>
              </TouchableOpacity>
              <View style={{
                backgroundColor:color.blue2, 
                alignItems:'center', 
                justifyContent:'center', 
                width:(WIDTH * 0.5),
                borderRadius:5,
                marginLeft:10,
                marginRight:10, 
                height:(HEIGHT * 0.08)
              }}>
                <Text style={{color:'white',fontSize:20}}>Rp. 9.999.999</Text>
              </View>
              <TouchableOpacity
                onPress={()=> this.props.navigation.navigate('TopUp')}
                style={{ 
                  flexDirection:'column',
                  justifyContent:'center',
                  alignItems:'center'
                }}
              >
                <Image style={{width:50,height:50,resizeMode:'contain'}} source={ImageLoader('logo_topup')}/>
                <Text style={{color:color.blue1,fontSize:16, fontWeight:'800', marginTop:10}}>Top Up</Text>
              </TouchableOpacity>
            </View>

            <View style={{justifyContent:"center",alignItems:'center'}}>
            {this.listItems()}
              <View style={{position:'absolute', right:10}}>
                <TouchableOpacity 
                  onPress={()=>this.setState({oPenModal:true})}
                  style={{ 
                    flexDirection:'column',
                    justifyContent:'center',
                    alignItems:'center'
                  }}
                >
                  <Image style={{width:30,height:30,resizeMode:'contain'}} source={ImageLoader('logo_help')}/>
                  <Text style={{color:color.blue1,fontSize:12, fontWeight:'800', marginTop:10}}>Help</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Content>


        <View style={{alignItems:'center'}}>
          <Image style={{height:(HEIGHT*0.25),resizeMode:'center'}} source={ImageLoader('banner')}/>
        </View>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  img_logo:{
    width: 60, 
    height: 70,
    resizeMode:'contain',
    marginBottom:10
  },
  img_icon:{
    resizeMode: 'contain',
    width: 50,
    marginTop:50/2,
    height: 50
  },
  img_icon2:{
    resizeMode: 'contain',
    marginRight:10/2,
    width: 45,
    marginTop:25/2,
    height: 45
  },
  opacity:{
    alignItems:'center',
    width:80,
    position:'absolute',
    bottom:10,
    height:80,
    borderWidth: 5,
    borderColor: '#f7f8fa',
    borderRadius: 80/2
  },
  view_icon:{
    alignItems: 'center',
    marginTop: 20,
    width: 100, 
    height: 100,  
    borderRadius: 100/2,
  },
  avatar:{
    top: -80,
    flexDirection: 'column',
    alignItems: 'center'
  }
});

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(Home);
