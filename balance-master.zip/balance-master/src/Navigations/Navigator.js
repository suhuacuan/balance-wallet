import {
  createStackNavigator,
  createSwitchNavigator,
  createAppContainer
} from 'react-navigation';
  
// ***** Import Pages ***** //
// ** Front Pages
import Splash from 'Balance/src/Pages/Splash';
import Login from 'Balance/src/Pages/Login/Login';
import Register from 'Balance/src/Pages/Register/Register';
import Home from 'Balance/src/Pages/Home/Home';
import Convert from 'Balance/src/Pages/Convert/Convert';
import Settings from 'Balance/src/Pages/Settings/Settings';
import TopUp from 'Balance/src/Pages/TopUp/TopUp';
import Rate from 'Balance/src/Pages/Rate/Rate';
import ErrorPages from 'Balance/src/Pages/AfterScan/ErrorPages';
import InfoApp from 'Balance/src/Pages/InfoApp/InfoApp';
import Scanner from 'Balance/src/Pages/Scanner/Scanner';
import Counter from 'Balance/src/Pages/Counter';
// ***** /Import Pages ***** //
  
const MainStack = createStackNavigator({
  Login: { screen: Login }, 
  Register,
},{
  headerMode: 'none',
  navigationOptions: { headerVisible: false }
});

const OutStack = createStackNavigator({
  Settings,
},{
  headerMode: 'none',
  navigationOptions: { headerVisible: false }
});

const MainMenu = createStackNavigator({
  Home: { screen: Home},
  Convert: { screen:Convert },
  TopUp: { screen: TopUp},
  Rate: { screen: Rate},
  InfoApp: { screen: InfoApp},
  Scanner: { screen: Scanner },
  ErrorPages: { screen: ErrorPages},
  Counter: {screen: Counter}
},{
  headerMode: 'none',
  navigationOptions: { headerVisible: false }
});

const AppNavigator = createSwitchNavigator({
  Splash: {screen: Splash},
  MainStack: {screen: MainStack},
  MainMenu: { screen: MainMenu },
  OutStack: { screen:OutStack }
},  {
  navigationOptions: { headerVisible: false },
  initialRouteName: 'Splash'
});

export default createAppContainer(AppNavigator);
