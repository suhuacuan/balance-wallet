import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Modal,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item,
  Tabs,
  Tab,
  TabHeading
} from "native-base";

import { connect } from 'react-redux';

import lang from 'Balance/src/Helpers/Language';
import * as Session from 'Balance/src/Helpers/Session';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const WIDTH = Dimensions.get('window').width;
const CARD = WIDTH * (45/100);
const maxWidth = WIDTH * (97/100);
const HEIGHT = Dimensions.get('window').height;
const columns = 4;

class HeaderDetail extends Component {

  dataItems = [
    {
      images: ImageLoader('logo_home'),
      name  : 'Home',
      nav   : 'Home'
    }, {
      images: ImageLoader('logo_transfer'),
      name  : 'Transfer',
      nav   : ''
    }, {
      images: ImageLoader('logo_convert'),
      name  : 'Convert',
      nav   : ''
    }, {
      images: ImageLoader('logo_manage_bank'),
      name  : 'Manage Bank',
      nav   : ''
    },
    {
      images: ImageLoader('logo_home'),
      name  : 'Home',
      nav   : ''
    }, {
      images: ImageLoader('logo_transfer'),
      name  : 'Transfer',
      nav   : ''
    }, {
      images: ImageLoader('logo_convert'),
      name  : 'Convert',
      nav   : 'Convert'
    }, {
      images: ImageLoader('logo_manage_bank'),
      name  : 'Manage Bank',
      nav   : ''
    }
  ];
  
  constructor(props) {
    super(props);
    this.state = {
      image:'',
      typeImg:'',
      oPenModal:false
    };
  }

  componentDidMount(){
   
  }

  render=()=> {
    return (
      <View style={{
        backgroundColor: '#ffffff',
        marginBottom: 20
      }}
      > 
        <View
          style={{
            alignItems:'center',
            backgroundColor:color.blue1
          }}
        >
          <View style={{marginTop:20,flexDirection:'row'}}>
            <Left>
              <Button transparent 
                onPress={()=>this.props.navigation.goBack()}>
                <Icon name='arrow-back' style={{fontSize:30,color:'white'}} />
              </Button>
            </Left>
            <Right>
              <Button transparent>
                <Icon name="notifications" style={{fontSize:30,color:'white'}}/>
              </Button>
            </Right>
          </View>

          <Image style={styles.img_logo} source={ImageLoader('logo2')}/>
        </View>
        
        <View style={{backgroundColor:color.blue1}}>
          <FlatList
            data={this.dataItems}
            horizontal={false}
            keyExtractor={ (item, index) => index.toString() }
            renderItem={({item, index}) => {
              return (
                <View style={{width: (CARD * 0.48), marginHorizontal: 5, marginTop:10, marginBottom:5}}>
                  <TouchableOpacity 
                    onPress={()=> this.props.navigation.navigate(item.nav)}
                    style={{ 
                      flexDirection:'column',
                      justifyContent:'center',
                      alignItems:'center'
                    }}
                  >
                    <Image style={{width:20,height:20,resizeMode:'contain'}} source={item.images}/>
                    <Text style={{color:'white',fontSize:12, marginTop:5}}>{item.name}</Text>
                  </TouchableOpacity>
                </View>
              );
              }
            }
            numColumns={columns}
          />
        </View>

        
      </View>
    );
  }
}

const styles = StyleSheet.create({
  img_logo:{
    width: 60, 
    height: 70,
    resizeMode:'contain',
    marginBottom:10
  },
  img_icon:{
    resizeMode: 'contain',
    width: 50,
    marginTop:50/2,
    height: 50
  },
  img_icon2:{
    resizeMode: 'contain',
    marginRight:10/2,
    width: 45,
    marginTop:25/2,
    height: 45
  },
  opacity:{
    alignItems:'center',
    width:80,
    position:'absolute',
    bottom:10,
    height:80,
    borderWidth: 5,
    borderColor: '#f7f8fa',
    borderRadius: 80/2
  },
  view_icon:{
    alignItems: 'center',
    marginTop: 20,
    width: 100, 
    height: 100,  
    borderRadius: 100/2,
  },
  avatar:{
    top: -80,
    flexDirection: 'column',
    alignItems: 'center'
  }
});

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(HeaderDetail);
