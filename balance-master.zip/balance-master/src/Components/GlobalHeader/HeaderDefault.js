import React, {Component} from 'react';
import {
  Alert,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Keyboard,
  Linking,
  ImageBackground,
  FlatList,
  Modal,
  Dimensions
} from 'react-native';

import {
  Button,
  Text,
  Header,
  Content,
  Container,
  Form,
  Label,
  Left,
  List,
  Title,
  Right,
  Card,
  Fab,
  CardItem,
  Icon,
  ListItem,
  Body,
  Input,
  Item,
  Tabs,
  Tab,
  TabHeading
} from "native-base";

import { connect } from 'react-redux';

import lang from 'Balance/src/Helpers/Language';
import * as Session from 'Balance/src/Helpers/Session';
import ImageLoader from 'Balance/src/Helpers/ImagesLoader';
import { color } from 'Balance/src/Helpers/Style/ColorList';

const WIDTH = Dimensions.get('window').width;
const CARD = WIDTH * (45/100);
const maxWidth = WIDTH * (97/100);
const HEIGHT = Dimensions.get('window').height;
const columns = 4;

class HeaderDefault extends Component {

  dataItems = [
    {
      images: ImageLoader('logo_home'),
      name  : 'Home',
      nav   : 'Home'
    }, {
      images: ImageLoader('logo_transfer'),
      name  : 'Transfer',
      nav   : ''
    }, {
      images: ImageLoader('logo_convert'),
      name  : 'Convert',
      nav   : 'Convert'
    }, {
      images: ImageLoader('logo_manage_bank'),
      name  : 'Manage Bank',
      nav   : ''
    }
  ];
  
  constructor(props) {
    super(props);
    this.state = {
      image:'',
      typeImg:'',
      oPenModal:false
    };
  }

  componentDidMount(){
   
  }

  render=()=> {
    return (
      <View style={{
        backgroundColor: '#ffffff',
        marginBottom: 20
      }}
      > 
        <View
          style={{
            alignItems:'center',
            backgroundColor:color.blue1
          }}
        >
          <View style={{marginTop:20,flexDirection:'row'}}>
            <Left>
              <Button transparent onPress={()=>this.props.navigation.navigate('Settings')}>
                <Icon name="menu" style={{fontSize:30,color:'white'}}/>
              </Button>
            </Left>
            <Right>
              <View style={{flexDirection:'row'}}>
                <Button transparent>
                  <Image style={{width:25,height:25,resizeMode:'contain'}} source={ImageLoader('logo2')}/>
                </Button>
                <Button transparent>
                  <Icon name="notifications" style={{fontSize:30,color:'white'}}/>
                </Button>
              </View>
            </Right>
          </View>

          <Image style={styles.img_logo} source={ImageLoader('logo2')}/>
        </View>
        
        <View style={{backgroundColor:color.blue1}}>
          <FlatList
            data={this.dataItems}
            horizontal={true}
            keyExtractor={ (item, index) => index.toString() }
            renderItem={({item, index}) => {
              return (
                <View style={{width: (CARD * 0.48), marginHorizontal: 5, marginTop:10, marginBottom:5}}>
                  <TouchableOpacity 
                    onPress={()=> this.props.navigation.navigate(item.nav)}
                    style={{ 
                      flexDirection:'column',
                      justifyContent:'center',
                      alignItems:'center'
                    }}
                  >
                    <Image style={{width:20,height:20,resizeMode:'contain'}} source={item.images}/>
                    <Text style={{color:'white',fontSize:12, marginTop:5}}>{item.name}</Text>
                  </TouchableOpacity>
                </View>
              );
              }
            }
          />
        </View>

        {/* <Tabs tabBarUnderlineStyle={{ backgroundColor:'white' }} >
          <Tab 
            tabStyle={{backgroundColor: color.blue1}} 
            textStyle={{color: 'white'}} 
            activeTabStyle={{backgroundColor: color.blue1}} 
            activeTextStyle={{color: 'white', fontWeight: 'normal'}} 
            heading={
              <TabHeading style={{
                backgroundColor:color.blue1,
                flexDirection:'column',
                alignItems:'center',
                justifyContent:'center'
              }}>
                <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('logo_home')}/>
                <Text style={{color:'white',fontSize:12, marginTop:5}}>Home</Text>
              </TabHeading>
            }>
          </Tab>
          <Tab 
            tabStyle={{backgroundColor: color.blue1}}
            textStyle={{color: 'white'}} 
            activeTabStyle={{backgroundColor: color.blue1}} 
            activeTextStyle={{color: 'white', fontWeight: 'normal'}} 
            heading={
              <TabHeading style={{
                backgroundColor:color.blue1,
                flexDirection:'column',
                alignItems:'center',
                justifyContent:'center'
              }}>
                <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('logo_transfer')}/>
                <Text style={{color:'white',fontSize:12, marginTop:5}}>Transfer</Text>
              </TabHeading>
            }>
          </Tab>
          <Tab 
            tabStyle={{backgroundColor: color.blue1}} 
            textStyle={{color: 'white'}} 
            activeTabStyle={{backgroundColor: color.blue1}} 
            activeTextStyle={{color: 'white', fontWeight: 'normal'}} 
            heading={
              <TabHeading style={{
                backgroundColor:color.blue1,
                flexDirection:'column',
                alignItems:'center',
                justifyContent:'center'
              }}>
                <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('logo_convert')}/>
                <Text style={{color:'white',fontSize:12, marginTop:5}}>Convert</Text>
              </TabHeading>
            }>
          </Tab>
          <Tab 
            tabStyle={{backgroundColor: color.blue1}} 
            textStyle={{color: 'white'}} 
            activeTabStyle={{backgroundColor: color.blue1}} 
            activeTextStyle={{color: 'white', fontWeight: 'normal'}} 
            heading={
              <TabHeading style={{
                backgroundColor:color.blue1,
                flexDirection:'column',
                alignItems:'center',
                justifyContent:'center'
              }}>
                <Image style={{width:20,height:20,resizeMode:'contain'}} source={ImageLoader('logo_manage_bank')}/>
                <Text style={{color:'white',fontSize:12, marginTop:5}}>Manage Bank</Text>
              </TabHeading>
            }>
          </Tab>
        </Tabs> */}

      </View>
    );
  }
}

const styles = StyleSheet.create({
  img_logo:{
    width: 60, 
    height: 70,
    resizeMode:'contain',
    marginBottom:10
  },
  img_icon:{
    resizeMode: 'contain',
    width: 50,
    marginTop:50/2,
    height: 50
  },
  img_icon2:{
    resizeMode: 'contain',
    marginRight:10/2,
    width: 45,
    marginTop:25/2,
    height: 45
  },
  opacity:{
    alignItems:'center',
    width:80,
    position:'absolute',
    bottom:10,
    height:80,
    borderWidth: 5,
    borderColor: '#f7f8fa',
    borderRadius: 80/2
  },
  view_icon:{
    alignItems: 'center',
    marginTop: 20,
    width: 100, 
    height: 100,  
    borderRadius: 100/2,
  },
  avatar:{
    top: -80,
    flexDirection: 'column',
    alignItems: 'center'
  }
});

const mapStateToProps = state => ({
  counter: state.counter
});

export default connect(mapStateToProps)(HeaderDefault);
